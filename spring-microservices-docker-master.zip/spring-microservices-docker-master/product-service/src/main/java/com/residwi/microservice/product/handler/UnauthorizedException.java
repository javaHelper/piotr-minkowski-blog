package com.residwi.microservice.product.handler;

public class UnauthorizedException extends RuntimeException {
}
