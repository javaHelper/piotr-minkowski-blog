package com.residwi.microservice.product.handler;

public class NotFoundException extends RuntimeException {
}
