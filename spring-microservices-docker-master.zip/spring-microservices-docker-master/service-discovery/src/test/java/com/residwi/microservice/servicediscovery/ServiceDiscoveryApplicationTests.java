package com.residwi.microservice.servicediscovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDiscoveryApplicationTests {

    @Test
    void contextLoads() {
    }

}
