package com.residwi.microservice.member.handler;

public class NotFoundException extends RuntimeException{
}
