package com.residwi.microservice.member.handler;

public class UnauthorizedException extends RuntimeException {
}
