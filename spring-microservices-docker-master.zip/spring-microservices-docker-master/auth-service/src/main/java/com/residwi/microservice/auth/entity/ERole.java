package com.residwi.microservice.auth.entity;

public enum ERole {
    ROLE_USER
}
