# Discovery Service

Discovery service discovers services(service name, location) in microservices system for services communication purpose. 