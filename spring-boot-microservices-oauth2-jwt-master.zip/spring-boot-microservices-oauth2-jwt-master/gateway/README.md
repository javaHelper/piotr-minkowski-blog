# Gateway Service

Gateway service is responsible for request routing, composition, and protocol translation. All requests from clients first go through the Gateway. It then routes requests to the appropriate microservice.