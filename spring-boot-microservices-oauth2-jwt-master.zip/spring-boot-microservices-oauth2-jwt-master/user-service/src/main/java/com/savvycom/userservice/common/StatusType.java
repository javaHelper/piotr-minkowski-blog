package com.savvycom.userservice.common;

public class StatusType {
    public static final boolean ACTIVE = true;
    public static final boolean IN_ACTIVE = false;
}
