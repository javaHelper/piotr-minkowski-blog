package com.savvycom.userservice.common;

public class PaymentType {
    public static final String CASH_IN_HAND = "cash in hand";
}
