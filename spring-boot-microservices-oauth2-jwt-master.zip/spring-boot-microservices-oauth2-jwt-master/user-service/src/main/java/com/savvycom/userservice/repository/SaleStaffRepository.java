package com.savvycom.userservice.repository;

import com.savvycom.userservice.domain.entity.SaleStaff;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SaleStaffRepository extends JpaRepository<SaleStaff, Long> {

}
