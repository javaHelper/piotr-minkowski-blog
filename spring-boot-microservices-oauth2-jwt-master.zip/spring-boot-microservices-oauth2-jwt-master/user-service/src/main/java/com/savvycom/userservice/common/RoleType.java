package com.savvycom.userservice.common;

public class RoleType {
    public static final String ADMIN = "admin";
    public static final String USER = "user";
}
