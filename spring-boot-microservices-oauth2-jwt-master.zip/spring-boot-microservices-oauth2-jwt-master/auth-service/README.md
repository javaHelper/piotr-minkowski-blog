# Auth Service

Auth service implements user authentication and authorization functionalities with Spring security OAuth2 JWT